document.addEventListener("DOMContentLoaded", () => {
  const grabImages = document.getElementById("grabImages");
  const grabVideos = document.getElementById("grabVideos");
  const form = document.getElementById("settings-form");
  const settingsPanel = document.getElementById("settings-panel");
  const toggleSettings = document.getElementById("toggle-settings");
  const previewModal = document.getElementById("preview-modal");
  const smartButton = document.getElementById("smartButton");
  const closePreview = document.getElementById("close-preview");
  const previewContent = document.getElementById("preview-content");
  const mediaList = document.getElementById("media-list");

  // --- Helper Functions ---

  const showToast = (message, duration = 3000) => {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      container.contains(toast) && container.removeChild(toast);
    }, duration);
  };

  const showNoMediaCard = () => {
    mediaList.innerHTML = "";
    const noMediaCard = document.createElement("div");
    noMediaCard.className = "media-card no-media-card";
    noMediaCard.innerHTML = `
      <div class="no-media-icon">
        <i class="fas fa-folder-open"></i>
      </div>
      <div class="no-media-text">
        <h3>No Media Found!</h3>
        <p>Please ensure you're on the right page!</p>
      </div>
    `;
    mediaList.appendChild(noMediaCard);
  };

  const createSection = (title, items) => {
    const section = document.createElement("div");
    section.className = "media-section";

    const heading = document.createElement("h3");
    heading.textContent = title;
    section.appendChild(heading);

    items.forEach((item) => {
      const card = document.createElement("div");
      card.className = "card";

      // Clean file name
      let cleanName = item.name.split("?")[0];
      if (cleanName.length > 25) {
        const extIndex = cleanName.lastIndexOf(".");
        const extension = extIndex !== -1 ? cleanName.substring(extIndex) : "";
        cleanName = cleanName.substring(0, 20) + "..." + extension;
      }

      const nameEl = document.createElement("h4");
      nameEl.textContent = cleanName;
      card.appendChild(nameEl);

      const sizeEl = document.createElement("div");
      sizeEl.className = "size";
      sizeEl.textContent =
        "Size: " + (item.size && item.size !== "0x0" ? item.size : "unknown");
      card.appendChild(sizeEl);

      const buttons = document.createElement("div");
      buttons.className = "buttons";

      // Download button
      const download = document.createElement("button");
      download.innerHTML = '<i class="fas fa-download"></i>';
      download.title = "Download";
      download.onclick = () =>
        chrome.downloads.download({ url: item.src, filename: cleanName });

      // Preview button
      const preview = document.createElement("button");
      preview.innerHTML = '<i class="fas fa-eye"></i>';
      preview.title = "Preview";
      preview.onclick = () => showPreview(item);

      // Copy URL button
      const copy = document.createElement("button");
      copy.innerHTML = '<i class="fas fa-copy"></i>';
      copy.title = "Copy URL";
      copy.onclick = () => {
        navigator.clipboard.writeText(item.src);
        showToast("Copied to clipboard!");
      };

      buttons.append(download, preview, copy);
      card.appendChild(buttons);

      section.appendChild(card);
    });

    return section;
  };

  const showPreview = (item) => {
    previewContent.innerHTML = "";

    if (item.type === "image") {
      const img = document.createElement("img");
      img.src = item.src;
      img.style.maxWidth = "100%";
      img.style.maxHeight = "100%";
      previewContent.appendChild(img);
    } else if (item.type === "video") {
      const video = document.createElement("video");
      video.src = item.src;
      video.controls = true;
      video.style.maxWidth = "100%";
      video.style.maxHeight = "100%";
      previewContent.appendChild(video);
    }
    const smtBtn = document.createElement("a");
    smtBtn.style.textDecoration = "none";
    smtBtn.style.backgroundColor = "#1e2a38";
    smtBtn.style.color = "#ffff";
    smtBtn.setAttribute("href", "https://otieu.com/4/9091242");
    smtBtn.setAttribute("target", "_blank");
    smtBtn.innerHTML = '<i class="fa-solid fa-download"></i> Download';
    smtBtn.classList.add("smartLink");
    smartButton.appendChild(smtBtn);
    previewModal.classList.remove("hidden");
  };

  const displayMedia = (media) => {
    mediaList.innerHTML = "";

    chrome.storage.sync.get(["grabImages", "grabVideos"], (settings) => {
      const showImages = settings.grabImages !== false;
      const showVideos = settings.grabVideos !== false;

      if (!media || media.length === 0) {
        showNoMediaCard();
        return;
      }

      const videos = media.filter((m) => m.type === "video");
      const images = media.filter((m) => m.type === "image");
      let appended = false;

      if (videos.length && (showVideos || (!showImages && !showVideos))) {
        mediaList.appendChild(createSection("Videos", videos));
        appended = true;
      }

      if (images.length && (showImages || (!showImages && !showVideos))) {
        mediaList.appendChild(createSection("Images", images));
        appended = true;
      }

      if (!appended) showNoMediaCard();
    });
  };

  const scanMedia = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab || !tab.url || tab.url.startsWith("chrome://")) {
        showToast("Cannot scan this page.");
        return;
      }
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content/content.js"],
      });
    });
  };

  // --- Event Listeners ---
  toggleSettings.addEventListener("click", () =>
    settingsPanel.classList.toggle("hidden")
  );
  closePreview.addEventListener("click", () =>
    previewModal.classList.add("hidden")
  );

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    chrome.storage.sync.set(
      { grabImages: grabImages.checked, grabVideos: grabVideos.checked },
      () => {
        showToast("Settings saved!");
        settingsPanel.classList.add("hidden");
        scanMedia();
      }
    );
  });

  // Load initial settings
  chrome.storage.sync.get(["grabImages", "grabVideos"], (data) => {
    grabImages.checked = data.grabImages !== false;
    grabVideos.checked = data.grabVideos !== false;
  });

  // Listen for media from content script
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "mediaFound") displayMedia(message.media);
  });

  // Initial scan and show no media placeholder
  scanMedia();
  showNoMediaCard();
});
