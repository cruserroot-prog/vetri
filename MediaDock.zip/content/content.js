(function() {
    chrome.storage.sync.get(['grabImages', 'grabVideos'], data => {
        const results = [];

        if (data.grabImages !== false) {
            document.querySelectorAll('img').forEach(img => {
                if (img.src && img.naturalWidth > 50) {
                    results.push({
                        type: 'image',
                        src: img.src,
                        name: img.src.split('/').pop() || 'image',
                        size: `${img.naturalWidth}x${img.naturalHeight}`
                    });
                }
            });
        }

        if (data.grabVideos !== false) {
            document.querySelectorAll('video').forEach(video => {
                if (video.currentSrc) {
                    let width = video.videoWidth || 0;
                    let height = video.videoHeight || 0;

                    if (width === 0 || height === 0) {
                        width = video.getAttribute('width') || 0;
                        height = video.getAttribute('height') || 0;
                    }

                    results.push({
                        type: 'video',
                        src: video.currentSrc,
                        name: video.currentSrc.split('/').pop() || 'video',
                        size: `${width}x${height}`
                    });
                }
            });
        }

        chrome.runtime.sendMessage({ action: 'mediaFound', media: results });
    });
})();
