chrome.runtime.onInstalled.addListener(() => {
    chrome.action.setBadgeText({ text: '' });
});

chrome.runtime.onMessage.addListener((message, sender) => {
    if (message.action === 'mediaFound') {
        const count = message.media.length;
        chrome.action.setBadgeText({ text: count > 0 ? count.toString() : '' });
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        chrome.action.setBadgeText({ text: '' });
    }
});
